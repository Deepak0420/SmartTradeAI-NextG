package com.example.domain.engine

import com.example.data.model.Candle
import com.example.data.model.TechnicalIndicators
import kotlin.math.abs
import kotlin.math.max

object IndicatorCalculator {

    fun calculateIndicators(candles: List<Candle>): TechnicalIndicators {
        if (candles.size < 30) {
            return TechnicalIndicators()
        }

        val closes = candles.map { it.close }

        // EMA 9 and EMA 21
        val ema9Series = calculateEmaSeries(closes, 9)
        val ema21Series = calculateEmaSeries(closes, 21)
        val currentEma9 = ema9Series.lastOrNull()
        val currentEma21 = ema21Series.lastOrNull()

        // RSI 14
        val currentRsi14 = calculateRsi(closes, 14)

        // MACD 12/26/9
        val macdResult = calculateMacd(closes, 12, 26, 9)

        // VWAP
        val currentVwap = calculateVwap(candles)

        // ATR 14
        val currentAtr14 = calculateAtr(candles, 14)

        return TechnicalIndicators(
            ema9 = currentEma9,
            ema21 = currentEma21,
            rsi14 = currentRsi14,
            macdLine = macdResult?.macdLine,
            macdSignal = macdResult?.signalLine,
            macdHistogram = macdResult?.histogram,
            vwap = currentVwap,
            atr14 = currentAtr14
        )
    }

    fun calculateEmaSeries(prices: List<Double>, period: Int): List<Double> {
        if (prices.size < period) return emptyList()

        val multiplier = 2.0 / (period + 1.0)
        val emaList = ArrayList<Double>(prices.size)

        // Initial SMA
        var sum = 0.0
        for (i in 0 until period) {
            sum += prices[i]
        }
        var prevEma = sum / period

        for (i in 0 until prices.size) {
            if (i < period - 1) {
                emaList.add(prices[i])
            } else if (i == period - 1) {
                emaList.add(prevEma)
            } else {
                val currentEma = (prices[i] - prevEma) * multiplier + prevEma
                emaList.add(currentEma)
                prevEma = currentEma
            }
        }
        return emaList
    }

    fun calculateRsi(closes: List<Double>, period: Int = 14): Double? {
        if (closes.size <= period) return null

        var gains = 0.0
        var losses = 0.0

        for (i in 1..period) {
            val change = closes[i] - closes[i - 1]
            if (change > 0) gains += change else losses += abs(change)
        }

        var avgGain = gains / period
        var avgLoss = losses / period

        for (i in (period + 1) until closes.size) {
            val change = closes[i] - closes[i - 1]
            val gain = if (change > 0) change else 0.0
            val loss = if (change < 0) abs(change) else 0.0

            avgGain = (avgGain * (period - 1) + gain) / period
            avgLoss = (avgLoss * (period - 1) + loss) / period
        }

        if (avgLoss == 0.0) return 100.0
        val rs = avgGain / avgLoss
        return 100.0 - (100.0 / (1.0 + rs))
    }

    data class MacdData(val macdLine: Double, val signalLine: Double, val histogram: Double)

    fun calculateMacd(
        closes: List<Double>,
        fastPeriod: Int = 12,
        slowPeriod: Int = 26,
        signalPeriod: Int = 9
    ): MacdData? {
        if (closes.size < slowPeriod + signalPeriod) return null

        val fastEma = calculateEmaSeries(closes, fastPeriod)
        val slowEma = calculateEmaSeries(closes, slowPeriod)

        val macdLineSeries = mutableListOf<Double>()
        for (i in slowEma.indices) {
            macdLineSeries.add(fastEma[i] - slowEma[i])
        }

        val signalSeries = calculateEmaSeries(macdLineSeries, signalPeriod)
        val lastMacd = macdLineSeries.lastOrNull() ?: return null
        val lastSignal = signalSeries.lastOrNull() ?: return null
        val histogram = lastMacd - lastSignal

        return MacdData(macdLine = lastMacd, signalLine = lastSignal, histogram = histogram)
    }

    fun calculateVwap(candles: List<Candle>): Double? {
        if (candles.isEmpty()) return null
        var cumulativeTypicalVolume = 0.0
        var cumulativeVolume = 0.0

        for (c in candles) {
            val typicalPrice = (c.high + c.low + c.close) / 3.0
            cumulativeTypicalVolume += typicalPrice * c.volume
            cumulativeVolume += c.volume
        }

        return if (cumulativeVolume > 0.0) cumulativeTypicalVolume / cumulativeVolume else null
    }

    fun calculateAtr(candles: List<Candle>, period: Int = 14): Double? {
        if (candles.size <= period) return null

        val trList = mutableListOf<Double>()
        for (i in 1 until candles.size) {
            val current = candles[i]
            val prev = candles[i - 1]
            val tr = max(
                current.high - current.low,
                max(
                    abs(current.high - prev.close),
                    abs(current.low - prev.close)
                )
            )
            trList.add(tr)
        }

        if (trList.size < period) return null

        var atr = trList.take(period).sum() / period
        for (i in period until trList.size) {
            atr = (atr * (period - 1) + trList[i]) / period
        }
        return atr
    }
}
