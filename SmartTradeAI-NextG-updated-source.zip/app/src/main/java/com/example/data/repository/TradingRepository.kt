package com.example.data.repository

import android.content.Context
import android.graphics.Bitmap
import android.util.Log
import com.example.data.api.MarketApiClient
import com.example.data.db.AppDatabase
import com.example.data.db.SignalEntity
import com.example.data.model.Candle
import com.example.data.model.MarketPair
import com.example.data.model.SignalType
import com.example.data.model.TechnicalIndicators
import com.example.data.model.Ticker24h
import com.example.data.model.Timeframe
import com.example.data.model.TradeSignal
import com.example.domain.engine.IndicatorCalculator
import com.example.domain.engine.SignalGenerator
import com.example.domain.ocr.ChartOcrScanner
import com.example.domain.ocr.OcrScanResult
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.launch

class TradingRepository(context: Context) {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private var refreshJob: Job? = null
    private var autoRefreshJob: Job? = null
    private val refreshIntervalMs = 5_000L
    private val apiClient = MarketApiClient()
    private val db = AppDatabase.getDatabase(context)
    private val signalDao = db.signalDao()
    private val ocrScanner = ChartOcrScanner()

    private val _selectedPair = MutableStateFlow(MarketPair.BTC_USDT)
    val selectedPair: StateFlow<MarketPair> = _selectedPair.asStateFlow()

    private val _selectedTimeframe = MutableStateFlow(Timeframe.ONE_MINUTE)
    val selectedTimeframe: StateFlow<Timeframe> = _selectedTimeframe.asStateFlow()

    private val _currentTicker = MutableStateFlow<Ticker24h?>(null)
    val currentTicker: StateFlow<Ticker24h?> = _currentTicker.asStateFlow()

    private val _currentCandles = MutableStateFlow<List<Candle>>(emptyList())
    val currentCandles: StateFlow<List<Candle>> = _currentCandles.asStateFlow()

    private val _currentIndicators = MutableStateFlow(TechnicalIndicators())
    val currentIndicators: StateFlow<TechnicalIndicators> = _currentIndicators.asStateFlow()

    private val _currentSignal = MutableStateFlow<TradeSignal?>(null)
    val currentSignal: StateFlow<TradeSignal?> = _currentSignal.asStateFlow()

    private val _ocrLastResult = MutableStateFlow<OcrScanResult?>(null)
    val ocrLastResult: StateFlow<OcrScanResult?> = _ocrLastResult.asStateFlow()

    private val _isLoading = MutableStateFlow(false)
    val isLoading: StateFlow<Boolean> = _isLoading.asStateFlow()

    private val _isContinuousScanning = MutableStateFlow(false)
    val isContinuousScanning: StateFlow<Boolean> = _isContinuousScanning.asStateFlow()

    private val _errorMessage = MutableStateFlow<String?>(null)
    val errorMessage: StateFlow<String?> = _errorMessage.asStateFlow()

    val signalHistory: Flow<List<TradeSignal>> = signalDao.getAllSignals().map { list ->
        list.map { it.toTradeSignal() }
    }

    init {
        startAutoRefresh()
    }

    /**
     * Poll Binance Spot public market data every five seconds while the app process is alive.
     * This is a polling fallback, not an exchange WebSocket connection and not guaranteed tick-by-tick data.
     */
    private fun startAutoRefresh() {
        if (autoRefreshJob?.isActive == true) return
        autoRefreshJob = scope.launch {
            while (isActive) {
                refreshMarketData()
                delay(refreshIntervalMs)
            }
        }
    }

    fun selectPair(pair: MarketPair) {
        if (_selectedPair.value != pair) {
            _selectedPair.value = pair
            refreshMarketData()
        }
    }

    fun selectTimeframe(tf: Timeframe) {
        if (_selectedTimeframe.value != tf) {
            _selectedTimeframe.value = tf
            refreshMarketData()
        }
    }

    fun setContinuousScanning(enabled: Boolean) {
        _isContinuousScanning.value = enabled
    }

    fun clearErrorMessage() {
        _errorMessage.value = null
    }

    fun refreshMarketData() {
        if (refreshJob?.isActive == true) return
        refreshJob = scope.launch {
            _isLoading.value = true
            _errorMessage.value = null
            val pair = _selectedPair.value
            val tf = _selectedTimeframe.value

            try {
                // 1. Fetch Ticker
                val tickerResult = apiClient.fetch24hTicker(pair.symbol)
                tickerResult.onSuccess {
                    _currentTicker.value = it
                }.onFailure {
                    Log.w("TradingRepository", "Ticker error: ${it.message}")
                }

                // 2. Fetch Klines
                val klinesResult = apiClient.fetchKlines(pair.symbol, tf.interval, limit = 100)
                klinesResult.onSuccess { candles ->
                    _currentCandles.value = candles

                    // 3. Calculate Indicators
                    val indicators = IndicatorCalculator.calculateIndicators(candles)
                    _currentIndicators.value = indicators

                    val price = _currentTicker.value?.lastPrice ?: candles.lastOrNull()?.close ?: 0.0

                    // 4. Generate Signal
                    val signal = SignalGenerator.generateSignal(
                        pair = pair.displayName,
                        timeframe = tf.interval,
                        currentPrice = price,
                        candles = candles,
                        indicators = indicators,
                        source = "BINANCE_SPOT_PUBLIC_POLLING"
                    )

                    _currentSignal.value = signal

                    // Save non-neutral signals to history
                    if (signal.type != SignalType.NEUTRAL) {
                        saveSignalToHistory(signal)
                    }
                }.onFailure {
                    _errorMessage.value = it.message ?: "Market data fetch error"
                }

            } catch (e: Exception) {
                Log.e("TradingRepository", "Refresh error: ${e.message}")
                _errorMessage.value = "Market fetch me truti: ${e.localizedMessage}"
            } finally {
                _isLoading.value = false
            }
        }
    }

    suspend fun analyzeScreenBitmap(bitmap: Bitmap): OcrScanResult {
        val ocrResult = ocrScanner.analyzeChartBitmap(bitmap)
        _ocrLastResult.value = ocrResult

        if (ocrResult.detectedPair != null && ocrResult.detectedPair != _selectedPair.value) {
            _selectedPair.value = ocrResult.detectedPair
        }

        // Generate signal based on OCR detection and live indicators
        val candles = _currentCandles.value
        val indicators = _currentIndicators.value
        val pairName = ocrResult.detectedPair?.displayName ?: _selectedPair.value.displayName
        val price = ocrResult.detectedPrice ?: _currentTicker.value?.lastPrice ?: candles.lastOrNull()?.close ?: 0.0

        if (candles.isNotEmpty() && price > 0.0) {
            val signal = SignalGenerator.generateSignal(
                pair = pairName,
                timeframe = ocrResult.detectedTimeframe ?: _selectedTimeframe.value.interval,
                currentPrice = price,
                candles = candles,
                indicators = indicators,
                source = "SCREEN_OCR"
            )
            _currentSignal.value = signal
            if (signal.type != SignalType.NEUTRAL) {
                saveSignalToHistory(signal)
            }
        }

        return ocrResult
    }

    private fun saveSignalToHistory(signal: TradeSignal) {
        scope.launch {
            try {
                signalDao.insertSignal(SignalEntity.fromTradeSignal(signal))
            } catch (e: Exception) {
                Log.e("TradingRepository", "Failed to save signal: ${e.message}")
            }
        }
    }

    fun clearSignalHistory() {
        scope.launch {
            signalDao.clearAll()
        }
    }

    fun deleteSignal(id: Long) {
        scope.launch {
            signalDao.deleteSignal(id)
        }
    }
}
