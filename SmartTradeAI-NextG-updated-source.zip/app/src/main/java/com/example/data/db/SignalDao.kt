package com.example.data.db

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface SignalDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSignal(signal: SignalEntity): Long

    @Query("SELECT * FROM signals ORDER BY timestamp DESC")
    fun getAllSignals(): Flow<List<SignalEntity>>

    @Query("SELECT * FROM signals WHERE pair = :pair ORDER BY timestamp DESC")
    fun getSignalsByPair(pair: String): Flow<List<SignalEntity>>

    @Query("DELETE FROM signals WHERE id = :id")
    suspend fun deleteSignal(id: Long)

    @Query("DELETE FROM signals")
    suspend fun clearAll()
}
