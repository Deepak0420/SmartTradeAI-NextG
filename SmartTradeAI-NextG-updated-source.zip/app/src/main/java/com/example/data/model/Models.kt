package com.example.data.model

enum class MarketPair(val symbol: String, val displayName: String, val baseAsset: String, val quoteAsset: String) {
    BTC_USDT("BTCUSDT", "BTC/USDT", "BTC", "USDT"),
    ETH_USDT("ETHUSDT", "ETH/USDT", "ETH", "USDT");

    companion object {
        fun fromSymbol(symbol: String): MarketPair {
            val clean = symbol.uppercase().replace("/", "").replace("-", "")
            return values().firstOrNull { it.symbol == clean } ?: BTC_USDT
        }
    }
}

enum class Timeframe(val interval: String, val label: String) {
    ONE_MINUTE("1m", "1m (Default)"),
    FIVE_MINUTES("5m", "5m"),
    FIFTEEN_MINUTES("15m", "15m");
}

data class Candle(
    val openTime: Long,
    val open: Double,
    val high: Double,
    val low: Double,
    val close: Double,
    val volume: Double,
    val closeTime: Long
)

data class Ticker24h(
    val symbol: String,
    val lastPrice: Double,
    val priceChangePercent: Double,
    val highPrice: Double,
    val lowPrice: Double,
    val volume: Double
)

data class TechnicalIndicators(
    val ema9: Double? = null,
    val ema21: Double? = null,
    val rsi14: Double? = null,
    val macdLine: Double? = null,
    val macdSignal: Double? = null,
    val macdHistogram: Double? = null,
    val vwap: Double? = null,
    val atr14: Double? = null
)

enum class SignalType(val titleHinglish: String, val shortLabel: String) {
    BUY("BUY SIGNAL (Kharido)", "BUY"),
    SELL("SELL SIGNAL (Becho)", "SELL"),
    NEUTRAL("HOLD / INTEZAR (No Trade)", "WAIT")
}

data class TradeSignal(
    val id: Long = 0,
    val timestamp: Long = System.currentTimeMillis(),
    val pair: String,
    val timeframe: String,
    val type: SignalType,
    val entryPrice: Double,
    val stopLoss: Double,
    val target1: Double,
    val target2: Double,
    val riskRewardRatio: Double,
    val reasons: List<String>,
    val source: String = "LIVE_API", // LIVE_API or SCREEN_OCR
    val status: String = "ACTIVE"
)
