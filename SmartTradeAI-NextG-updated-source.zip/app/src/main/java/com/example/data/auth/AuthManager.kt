package com.example.data.auth

import android.content.Context
import android.content.SharedPreferences
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

data class TraderProfile(
    val traderName: String = "Smart Trader",
    val experienceLevel: String = "Intermediate",
    val riskTolerance: String = "Moderate", // Conservative, Moderate, Aggressive
    val riskPercentPerTrade: Double = 1.5,
    val isHinglishPreferred: Boolean = true,
    val isTermsAccepted: Boolean = false
)

class AuthManager(context: Context) {
    private val prefs: SharedPreferences =
        context.getSharedPreferences("smarttrade_auth_prefs", Context.MODE_PRIVATE)

    private val _currentProfile = MutableStateFlow(loadProfile())
    val currentProfile: StateFlow<TraderProfile> = _currentProfile.asStateFlow()

    private fun loadProfile(): TraderProfile {
        val name = prefs.getString("trader_name", "Smart Trader") ?: "Smart Trader"
        val exp = prefs.getString("trader_exp", "Intermediate") ?: "Intermediate"
        val risk = prefs.getString("trader_risk", "Moderate") ?: "Moderate"
        val riskPct = prefs.getFloat("trader_risk_pct", 1.5f).toDouble()
        val terms = prefs.getBoolean("trader_terms_accepted", false)
        return TraderProfile(
            traderName = name,
            experienceLevel = exp,
            riskTolerance = risk,
            riskPercentPerTrade = riskPct,
            isHinglishPreferred = true,
            isTermsAccepted = terms
        )
    }

    fun updateProfile(
        name: String,
        exp: String,
        risk: String,
        riskPct: Double,
        termsAccepted: Boolean = true
    ) {
        prefs.edit()
            .putString("trader_name", name)
            .putString("trader_exp", exp)
            .putString("trader_risk", risk)
            .putFloat("trader_risk_pct", riskPct.toFloat())
            .putBoolean("trader_terms_accepted", termsAccepted)
            .apply()

        _currentProfile.value = loadProfile()
    }

    fun acceptTerms() {
        prefs.edit().putBoolean("trader_terms_accepted", true).apply()
        _currentProfile.value = loadProfile()
    }
}
