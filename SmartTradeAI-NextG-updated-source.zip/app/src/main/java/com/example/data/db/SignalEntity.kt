package com.example.data.db

import androidx.room.Entity
import androidx.room.PrimaryKey
import com.example.data.model.SignalType
import com.example.data.model.TradeSignal

@Entity(tableName = "signals")
data class SignalEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val timestamp: Long,
    val pair: String,
    val timeframe: String,
    val type: String,
    val entryPrice: Double,
    val stopLoss: Double,
    val target1: Double,
    val target2: Double,
    val riskRewardRatio: Double,
    val reasonsString: String, // pipe separated reasons
    val source: String,
    val status: String
) {
    fun toTradeSignal(): TradeSignal {
        return TradeSignal(
            id = id,
            timestamp = timestamp,
            pair = pair,
            timeframe = timeframe,
            type = try {
                SignalType.valueOf(type)
            } catch (e: Exception) {
                SignalType.NEUTRAL
            },
            entryPrice = entryPrice,
            stopLoss = stopLoss,
            target1 = target1,
            target2 = target2,
            riskRewardRatio = riskRewardRatio,
            reasons = if (reasonsString.isBlank()) emptyList() else reasonsString.split("|||"),
            source = source,
            status = status
        )
    }

    companion object {
        fun fromTradeSignal(signal: TradeSignal): SignalEntity {
            return SignalEntity(
                id = signal.id,
                timestamp = signal.timestamp,
                pair = signal.pair,
                timeframe = signal.timeframe,
                type = signal.type.name,
                entryPrice = signal.entryPrice,
                stopLoss = signal.stopLoss,
                target1 = signal.target1,
                target2 = signal.target2,
                riskRewardRatio = signal.riskRewardRatio,
                reasonsString = signal.reasons.joinToString("|||"),
                source = signal.source,
                status = signal.status
            )
        }
    }
}
