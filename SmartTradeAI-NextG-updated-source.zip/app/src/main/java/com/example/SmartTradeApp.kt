package com.example

import android.app.Application
import android.app.NotificationChannel
import android.app.NotificationManager
import android.os.Build
import com.example.data.auth.AuthManager
import com.example.data.repository.TradingRepository

class SmartTradeApp : Application() {

    lateinit var tradingRepository: TradingRepository
        private set

    lateinit var authManager: AuthManager
        private set

    override fun onCreate() {
        super.onCreate()
        instance = this
        authManager = AuthManager(this)
        tradingRepository = TradingRepository(this)
        createNotificationChannels()
    }

    private fun createNotificationChannels() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                NOTIFICATION_CHANNEL_ID,
                "SmartTradeAI Assistant",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Active trading assistant overlay and screen scanner notification"
            }
            val manager = getSystemService(NotificationManager::class.java)
            manager?.createNotificationChannel(channel)
        }
    }

    companion object {
        const val NOTIFICATION_CHANNEL_ID = "smarttrade_assistant_channel"
        const val NOTIFICATION_ID = 1001

        lateinit var instance: SmartTradeApp
            private set
    }
}
