package com.example

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.TrendingUp
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.example.service.FloatingAssistantService
import com.example.ui.screens.DashboardScreen
import com.example.ui.screens.OcrScannerScreen
import com.example.ui.screens.RiskSettingsScreen
import com.example.ui.screens.SignalsHistoryScreen
import com.example.ui.theme.CyanAccent
import com.example.ui.theme.DarkBorder
import com.example.ui.theme.DarkSurface
import com.example.ui.theme.SmartTradeTheme
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextSecondary
import com.example.ui.viewmodel.TradingViewModel

class MainActivity : ComponentActivity() {

    private val viewModel: TradingViewModel by viewModels()

    private val mediaProjectionLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK && result.data != null) {
            FloatingAssistantService.startServiceWithProjection(
                this,
                result.resultCode,
                result.data!!
            )
            Toast.makeText(this, "Floating Assistant chalu ho gaya hai!", Toast.LENGTH_SHORT).show()
        } else {
            Toast.makeText(this, "Screen capture permission manaa kiya gaya.", Toast.LENGTH_SHORT).show()
        }
    }

    private val overlayPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) {
        if (Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "Overlay permission mil gayi hai!", Toast.LENGTH_SHORT).show()
        }
    }

    private val notificationPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { /* handled */ }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
                != PackageManager.PERMISSION_GRANTED
            ) {
                notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
            }
        }

        setContent {
            SmartTradeTheme {
                MainAppNavHost(
                    viewModel = viewModel,
                    hasOverlayPermission = Settings.canDrawOverlays(this),
                    onRequestOverlayPermission = { requestOverlayPermission() },
                    onRequestMediaProjection = { requestMediaProjection() },
                    onStopAssistant = { stopFloatingAssistant() }
                )
            }
        }
    }

    private fun requestOverlayPermission() {
        if (!Settings.canDrawOverlays(this)) {
            val intent = Intent(
                Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:$packageName")
            )
            overlayPermissionLauncher.launch(intent)
        }
    }

    private fun requestMediaProjection() {
        if (!Settings.canDrawOverlays(this)) {
            requestOverlayPermission()
            return
        }
        val mpManager = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        mediaProjectionLauncher.launch(mpManager.createScreenCaptureIntent())
    }

    private fun stopFloatingAssistant() {
        FloatingAssistantService.stopService(this)
        viewModel.stopScan()
        Toast.makeText(this, "Floating Assistant band kar diya gaya.", Toast.LENGTH_SHORT).show()
    }
}

enum class NavigationTab(val label: String, val testTag: String) {
    DASHBOARD("Dashboard", "tab_dashboard"),
    HISTORY("Signals", "tab_history"),
    SCANNER("Scanner", "tab_scanner"),
    RISK("Risk Mgmt", "tab_risk")
}

@Composable
fun MainAppNavHost(
    viewModel: TradingViewModel,
    hasOverlayPermission: Boolean,
    onRequestOverlayPermission: () -> Unit,
    onRequestMediaProjection: () -> Unit,
    onStopAssistant: () -> Unit
) {
    var currentTab by remember { mutableStateOf(NavigationTab.DASHBOARD) }

    val selectedPair by viewModel.selectedPair.collectAsState()
    val selectedTimeframe by viewModel.selectedTimeframe.collectAsState()
    val ticker by viewModel.ticker.collectAsState()
    val candles by viewModel.candles.collectAsState()
    val indicators by viewModel.indicators.collectAsState()
    val signal by viewModel.signal.collectAsState()
    val isLoading by viewModel.isLoading.collectAsState()
    val errorMessage by viewModel.errorMessage.collectAsState()
    val isScanningActive by viewModel.isScanningActive.collectAsState()
    val ocrLastResult by viewModel.ocrLastResult.collectAsState()
    val signalHistory by viewModel.signalHistory.collectAsState()
    val profile by viewModel.traderProfile.collectAsState()

    Scaffold(
        bottomBar = {
            NavigationBar(
                containerColor = DarkSurface,
                tonalElevation = 8.dp,
                modifier = Modifier.testTag("main_bottom_nav_bar")
            ) {
                NavigationBarItem(
                    selected = currentTab == NavigationTab.DASHBOARD,
                    onClick = { currentTab = NavigationTab.DASHBOARD },
                    icon = { Icon(Icons.Default.TrendingUp, contentDescription = "Dashboard") },
                    label = { Text("Dashboard", fontSize = 10.sp) },
                    colors = navColors(),
                    modifier = Modifier.testTag(NavigationTab.DASHBOARD.testTag)
                )

                NavigationBarItem(
                    selected = currentTab == NavigationTab.HISTORY,
                    onClick = { currentTab = NavigationTab.HISTORY },
                    icon = { Icon(Icons.Default.History, contentDescription = "Signals") },
                    label = { Text("Signals", fontSize = 10.sp) },
                    colors = navColors(),
                    modifier = Modifier.testTag(NavigationTab.HISTORY.testTag)
                )

                NavigationBarItem(
                    selected = currentTab == NavigationTab.SCANNER,
                    onClick = { currentTab = NavigationTab.SCANNER },
                    icon = { Icon(Icons.Default.CameraAlt, contentDescription = "Scanner") },
                    label = { Text("Scanner", fontSize = 10.sp) },
                    colors = navColors(),
                    modifier = Modifier.testTag(NavigationTab.SCANNER.testTag)
                )

                NavigationBarItem(
                    selected = currentTab == NavigationTab.RISK,
                    onClick = { currentTab = NavigationTab.RISK },
                    icon = { Icon(Icons.Default.Security, contentDescription = "Risk Mgmt") },
                    label = { Text("Risk Mgmt", fontSize = 10.sp) },
                    colors = navColors(),
                    modifier = Modifier.testTag(NavigationTab.RISK.testTag)
                )
            }
        }
    ) { innerPadding ->
        when (currentTab) {
            NavigationTab.DASHBOARD -> DashboardScreen(
                selectedPair = selectedPair,
                onSelectPair = { viewModel.selectPair(it) },
                selectedTimeframe = selectedTimeframe,
                onSelectTimeframe = { viewModel.selectTimeframe(it) },
                ticker = ticker,
                candles = candles,
                indicators = indicators,
                signal = signal,
                isLoading = isLoading,
                errorMessage = errorMessage,
                onRefresh = { viewModel.refresh() },
                hasOverlayPermission = hasOverlayPermission,
                onRequestOverlayPermission = onRequestOverlayPermission,
                onRequestMediaProjection = onRequestMediaProjection,
                onStopAssistant = onStopAssistant,
                isScanningActive = isScanningActive,
                modifier = Modifier.padding(innerPadding)
            )

            NavigationTab.HISTORY -> SignalsHistoryScreen(
                signals = signalHistory,
                onDeleteSignal = { viewModel.deleteSignal(it) },
                onClearAll = { viewModel.clearAllSignals() },
                modifier = Modifier.padding(innerPadding)
            )

            NavigationTab.SCANNER -> OcrScannerScreen(
                lastOcrResult = ocrLastResult,
                isScanningActive = isScanningActive,
                onStartScan = { viewModel.startScan() },
                onStopScan = { viewModel.stopScan() },
                onPauseScan = { viewModel.pauseScan() },
                onRunDirectOcrTest = { bitmap -> viewModel.runDirectOcrTest(bitmap) },
                onRequestMediaProjection = onRequestMediaProjection,
                hasOverlayPermission = hasOverlayPermission,
                onRequestOverlayPermission = onRequestOverlayPermission,
                modifier = Modifier.padding(innerPadding)
            )

            NavigationTab.RISK -> RiskSettingsScreen(
                profile = profile,
                onUpdateProfile = { name, exp, risk, pct ->
                    viewModel.updateProfile(name, exp, risk, pct)
                },
                modifier = Modifier.padding(innerPadding)
            )
        }
    }
}

@Composable
private fun navColors() = NavigationBarItemDefaults.colors(
    selectedIconColor = CyanAccent,
    selectedTextColor = CyanAccent,
    unselectedIconColor = TextMuted,
    unselectedTextColor = TextSecondary,
    indicatorColor = DarkBorder
)
