package com.example.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.Candle
import com.example.domain.engine.IndicatorCalculator
import com.example.ui.theme.BearishRed
import com.example.ui.theme.BullishGreen
import com.example.ui.theme.DarkBorder
import com.example.ui.theme.DarkSurface
import com.example.ui.theme.Ema21Color
import com.example.ui.theme.Ema9Color
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.VwapColor
import java.util.Locale
import kotlin.math.max
import kotlin.math.min

@Composable
fun ChartCanvas(
    candles: List<Candle>,
    modifier: Modifier = Modifier
) {
    if (candles.isEmpty()) {
        Box(
            modifier = modifier
                .fillMaxWidth()
                .height(240.dp)
                .background(DarkSurface, RoundedCornerShape(12.dp)),
            contentAlignment = Alignment.Center
        ) {
            Text("Candle data load ho raha hai...", color = TextSecondary, fontSize = 13.sp)
        }
        return
    }

    // Display recent 30-40 candles for clean mobile view
    val displayCandles = remember(candles) {
        if (candles.size > 36) candles.takeLast(36) else candles
    }

    val closes = remember(displayCandles) { displayCandles.map { it.close } }
    val ema9List = remember(displayCandles) { IndicatorCalculator.calculateEmaSeries(closes, 9) }
    val ema21List = remember(displayCandles) { IndicatorCalculator.calculateEmaSeries(closes, 21) }
    val vwap = remember(displayCandles) { IndicatorCalculator.calculateVwap(displayCandles) }

    val minPrice = remember(displayCandles) {
        val minLow = displayCandles.minOfOrNull { it.low } ?: 0.0
        minLow * 0.999
    }
    val maxPrice = remember(displayCandles) {
        val maxHigh = displayCandles.maxOfOrNull { it.high } ?: 1.0
        maxHigh * 1.001
    }

    Column(
        modifier = modifier
            .fillMaxWidth()
            .background(DarkSurface, RoundedCornerShape(12.dp))
            .padding(12.dp)
            .testTag("chart_canvas_container")
    ) {
        // Legend row
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("1m Chart", color = TextSecondary, fontSize = 11.sp, style = MaterialTheme.typography.labelMedium)
            Spacer(modifier = Modifier.width(12.dp))

            LegendItem(color = Ema9Color, label = "EMA 9")
            Spacer(modifier = Modifier.width(8.dp))
            LegendItem(color = Ema21Color, label = "EMA 21")
            Spacer(modifier = Modifier.width(8.dp))
            LegendItem(color = VwapColor, label = "VWAP")

            Spacer(modifier = Modifier.weight(1f))
            Text(
                "Max: $${formatPrice(maxPrice)}",
                color = TextMuted,
                fontSize = 10.sp
            )
        }

        // Canvas for candles and indicator lines
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(200.dp)
        ) {
            Canvas(modifier = Modifier.fillMaxSize().testTag("candlestick_canvas")) {
                val canvasWidth = size.width
                val canvasHeight = size.height
                val priceRange = max(1.0, maxPrice - minPrice)

                fun priceToY(price: Double): Float {
                    val normalized = (price - minPrice) / priceRange
                    return (canvasHeight - (normalized * canvasHeight)).toFloat()
                }

                // Draw background grid lines (3 horizontal lines)
                val gridColor = Color(0x15FFFFFF)
                for (i in 1..3) {
                    val y = (canvasHeight / 4) * i
                    drawLine(
                        color = gridColor,
                        start = Offset(0f, y),
                        end = Offset(canvasWidth, y),
                        strokeWidth = 1f
                    )
                }

                val count = displayCandles.size
                if (count == 0) return@Canvas
                val slotWidth = canvasWidth / count
                val candleWidth = max(2f, slotWidth * 0.7f)

                // Draw Candles
                for (i in 0 until count) {
                    val c = displayCandles[i]
                    val centerX = i * slotWidth + slotWidth / 2f
                    val openY = priceToY(c.open)
                    val closeY = priceToY(c.close)
                    val highY = priceToY(c.high)
                    val lowY = priceToY(c.low)

                    val isBullish = c.close >= c.open
                    val color = if (isBullish) BullishGreen else BearishRed

                    // Draw Wick (High to Low line)
                    drawLine(
                        color = color,
                        start = Offset(centerX, highY),
                        end = Offset(centerX, lowY),
                        strokeWidth = 1.8f
                    )

                    // Draw Candle Body (Open to Close rect)
                    val bodyTop = min(openY, closeY)
                    val bodyBottom = max(openY, closeY)
                    val bodyHeight = max(2f, bodyBottom - bodyTop)

                    drawRect(
                        color = color,
                        topLeft = Offset(centerX - candleWidth / 2f, bodyTop),
                        size = Size(candleWidth, bodyHeight)
                    )
                }

                // Draw EMA 9 path
                if (ema9List.size == count) {
                    val ema9Path = Path()
                    for (i in 0 until count) {
                        val x = i * slotWidth + slotWidth / 2f
                        val y = priceToY(ema9List[i])
                        if (i == 0) ema9Path.moveTo(x, y) else ema9Path.lineTo(x, y)
                    }
                    drawPath(path = ema9Path, color = Ema9Color, style = Stroke(width = 2.2f))
                }

                // Draw EMA 21 path
                if (ema21List.size == count) {
                    val ema21Path = Path()
                    for (i in 0 until count) {
                        val x = i * slotWidth + slotWidth / 2f
                        val y = priceToY(ema21List[i])
                        if (i == 0) ema21Path.moveTo(x, y) else ema21Path.lineTo(x, y)
                    }
                    drawPath(path = ema21Path, color = Ema21Color, style = Stroke(width = 2.2f))
                }

                // Draw VWAP line
                if (vwap != null && vwap in minPrice..maxPrice) {
                    val vwapY = priceToY(vwap)
                    drawLine(
                        color = VwapColor,
                        start = Offset(0f, vwapY),
                        end = Offset(canvasWidth, vwapY),
                        strokeWidth = 1.5f
                    )
                }
            }
        }

        // Bottom price range summary
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(top = 4.dp)
        ) {
            Text(
                "Min: $${formatPrice(minPrice)}",
                color = TextMuted,
                fontSize = 10.sp
            )
            Spacer(modifier = Modifier.weight(1f))
            Text(
                "Live Indicators Overlaid",
                color = TextSecondary,
                fontSize = 10.sp
            )
        }
    }
}

@Composable
private fun LegendItem(color: Color, label: String) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(
            modifier = Modifier
                .size(8.dp)
                .background(color, RoundedCornerShape(2.dp))
        )
        Spacer(modifier = Modifier.width(4.dp))
        Text(label, color = color, fontSize = 10.sp)
    }
}

private fun formatPrice(price: Double): String {
    return if (price >= 100) {
        String.format(Locale.US, "%.1f", price)
    } else {
        String.format(Locale.US, "%.3f", price)
    }
}
