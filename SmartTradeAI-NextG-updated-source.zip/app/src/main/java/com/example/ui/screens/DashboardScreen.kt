package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.Candle
import com.example.data.model.MarketPair
import com.example.data.model.TechnicalIndicators
import com.example.data.model.Ticker24h
import com.example.data.model.Timeframe
import com.example.data.model.TradeSignal
import com.example.ui.components.ChartCanvas
import com.example.ui.components.FloatingAssistantLauncherCard
import com.example.ui.components.IndicatorsGrid
import com.example.ui.components.LivePriceCard
import com.example.ui.components.RiskWarningBanner
import com.example.ui.components.SignalHeroCard
import com.example.ui.theme.BearishRed
import com.example.ui.theme.BullishGreen
import com.example.ui.theme.CyanAccent
import com.example.ui.theme.DarkBg
import com.example.ui.theme.DarkSurface
import com.example.ui.theme.DarkSurfaceVariant
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DashboardScreen(
    selectedPair: MarketPair,
    onSelectPair: (MarketPair) -> Unit,
    selectedTimeframe: Timeframe,
    onSelectTimeframe: (Timeframe) -> Unit,
    ticker: Ticker24h?,
    candles: List<Candle>,
    indicators: TechnicalIndicators,
    signal: TradeSignal?,
    isLoading: Boolean,
    errorMessage: String?,
    onRefresh: () -> Unit,
    hasOverlayPermission: Boolean,
    onRequestOverlayPermission: () -> Unit,
    onRequestMediaProjection: () -> Unit,
    onStopAssistant: () -> Unit,
    isScanningActive: Boolean,
    modifier: Modifier = Modifier
) {
    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = "SmartTrade",
                            fontWeight = FontWeight.Black,
                            fontSize = 18.sp,
                            color = TextPrimary
                        )
                        Text(
                            text = "AI",
                            fontWeight = FontWeight.Black,
                            fontSize = 18.sp,
                            color = CyanAccent
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Box(
                            modifier = Modifier
                                .background(DarkSurfaceVariant, RoundedCornerShape(12.dp))
                                .padding(horizontal = 8.dp, vertical = 2.dp)
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(
                                    modifier = Modifier
                                        .size(6.dp)
                                        .background(BullishGreen, CircleShape)
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    text = "BINANCE SPOT • 5s refresh",
                                    color = BullishGreen,
                                    fontSize = 9.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = DarkSurface,
                    titleContentColor = TextPrimary
                ),
                modifier = Modifier.testTag("dashboard_top_bar")
            )
        },
        containerColor = DarkBg,
        modifier = modifier
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 14.dp, vertical = 8.dp)
                .testTag("dashboard_scroll_content")
        ) {
            // 1. Mandatory Risk Warning Banner
            RiskWarningBanner()

            Spacer(modifier = Modifier.height(10.dp))

            // Error alert if network or API has issues
            if (errorMessage != null) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(BearishRed.copy(alpha = 0.2f), RoundedCornerShape(8.dp))
                        .padding(10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Default.Warning,
                        contentDescription = "Error",
                        tint = BearishRed,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = errorMessage,
                        color = TextPrimary,
                        fontSize = 11.sp,
                        modifier = Modifier.weight(1f)
                    )
                    Button(
                        onClick = onRefresh,
                        colors = ButtonDefaults.buttonColors(containerColor = BearishRed),
                        shape = RoundedCornerShape(6.dp),
                        modifier = Modifier.testTag("btn_retry_network")
                    ) {
                        Text("Retry", fontSize = 11.sp)
                    }
                }
                Spacer(modifier = Modifier.height(10.dp))
            }

            // 2. Live Price Card with Pair Switcher & Timeframe
            LivePriceCard(
                selectedPair = selectedPair,
                onSelectPair = onSelectPair,
                selectedTimeframe = selectedTimeframe,
                onSelectTimeframe = onSelectTimeframe,
                ticker = ticker,
                isLoading = isLoading,
                onRefresh = onRefresh
            )

            Spacer(modifier = Modifier.height(10.dp))

            // 3. 1m Candlestick & Indicator Chart View
            ChartCanvas(candles = candles)

            Spacer(modifier = Modifier.height(10.dp))

            // 4. Hero Trade Signal Card (Entry, SL, Targets, Hinglish Reasons)
            SignalHeroCard(signal = signal)

            Spacer(modifier = Modifier.height(10.dp))

            // 5. Technical Indicators Breakdown (EMA, RSI, MACD, VWAP, ATR)
            val currentPrice = ticker?.lastPrice ?: candles.lastOrNull()?.close ?: 0.0
            IndicatorsGrid(
                indicators = indicators,
                currentPrice = currentPrice
            )

            Spacer(modifier = Modifier.height(10.dp))

            // 6. Floating Assistant & Screen OCR Launcher
            FloatingAssistantLauncherCard(
                hasOverlayPermission = hasOverlayPermission,
                onRequestOverlayPermission = onRequestOverlayPermission,
                onRequestMediaProjection = onRequestMediaProjection,
                onStopAssistant = onStopAssistant,
                isScanningActive = isScanningActive
            )

            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}
