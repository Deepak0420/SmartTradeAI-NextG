package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.History
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.SignalType
import com.example.data.model.TradeSignal
import com.example.ui.theme.BearishRed
import com.example.ui.theme.BearishRedBg
import com.example.ui.theme.BullishGreen
import com.example.ui.theme.BullishGreenBg
import com.example.ui.theme.CyanAccent
import com.example.ui.theme.DarkBg
import com.example.ui.theme.DarkBorder
import com.example.ui.theme.DarkSurface
import com.example.ui.theme.DarkSurfaceVariant
import com.example.ui.theme.GoldAccent
import com.example.ui.theme.NeutralYellow
import com.example.ui.theme.NeutralYellowBg
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SignalsHistoryScreen(
    signals: List<TradeSignal>,
    onDeleteSignal: (Long) -> Unit,
    onClearAll: () -> Unit,
    modifier: Modifier = Modifier
) {
    var filterPair by remember { mutableStateOf("ALL") }
    var filterType by remember { mutableStateOf("ALL") }
    var showClearDialog by remember { mutableStateOf(false) }

    val filteredList = remember(signals, filterPair, filterType) {
        signals.filter { s ->
            val matchPair = when (filterPair) {
                "BTC" -> s.pair.contains("BTC")
                "ETH" -> s.pair.contains("ETH")
                else -> true
            }
            val matchType = when (filterType) {
                "BUY" -> s.type == SignalType.BUY
                "SELL" -> s.type == SignalType.SELL
                else -> true
            }
            matchPair && matchType
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.History,
                            contentDescription = null,
                            tint = CyanAccent,
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "Signal History",
                            fontWeight = FontWeight.Bold,
                            fontSize = 17.sp,
                            color = TextPrimary
                        )
                    }
                },
                actions = {
                    if (signals.isNotEmpty()) {
                        IconButton(
                            onClick = { showClearDialog = true },
                            modifier = Modifier.testTag("btn_clear_history")
                        ) {
                            Icon(
                                imageVector = Icons.Default.Delete,
                                contentDescription = "Clear History",
                                tint = BearishRed
                            )
                        }
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = DarkSurface,
                    titleContentColor = TextPrimary
                )
            )
        },
        containerColor = DarkBg,
        modifier = modifier
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(horizontal = 14.dp, vertical = 8.dp)
                .testTag("history_screen_content")
        ) {
            // Filter Pills
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                FilterChip(label = "All Pairs", isSelected = filterPair == "ALL") { filterPair = "ALL" }
                FilterChip(label = "BTC Only", isSelected = filterPair == "BTC") { filterPair = "BTC" }
                FilterChip(label = "ETH Only", isSelected = filterPair == "ETH") { filterPair = "ETH" }
                Spacer(modifier = Modifier.weight(1f))
                FilterChip(label = "BUY", isSelected = filterType == "BUY") { filterType = if (filterType == "BUY") "ALL" else "BUY" }
                FilterChip(label = "SELL", isSelected = filterType == "SELL") { filterType = if (filterType == "SELL") "ALL" else "SELL" }
            }

            Spacer(modifier = Modifier.height(10.dp))

            if (filteredList.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(32.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(
                            text = "Abhi tak koi signal save nahi hua hai.",
                            color = TextSecondary,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Medium
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = "Market me jaise hi EMA, RSI aur MACD confirmation milta hai, naya BUY ya SELL signal yahan automatic log ho jayega.",
                            color = TextMuted,
                            fontSize = 11.sp,
                            lineHeight = 15.sp,
                            modifier = Modifier.padding(horizontal = 16.dp),
                            textAlign = androidx.compose.ui.text.style.TextAlign.Center
                        )
                    }
                }
            } else {
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    items(filteredList, key = { it.id }) { item ->
                        HistorySignalItem(
                            signal = item,
                            onDelete = { onDeleteSignal(item.id) }
                        )
                    }
                }
            }
        }
    }

    if (showClearDialog) {
        AlertDialog(
            onDismissRequest = { showClearDialog = false },
            title = { Text("Signal History Clear Karein?", color = TextPrimary) },
            text = { Text("Kya aap sabhi purane signals delete karna chahte hain? Ye action wapas nahi liya ja sakta.", color = TextSecondary) },
            confirmButton = {
                Button(
                    onClick = {
                        onClearAll()
                        showClearDialog = false
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = BearishRed)
                ) {
                    Text("Delete Karein")
                }
            },
            dismissButton = {
                OutlinedButton(onClick = { showClearDialog = false }) {
                    Text("Cancel")
                }
            },
            containerColor = DarkSurface
        )
    }
}

@Composable
private fun HistorySignalItem(
    signal: TradeSignal,
    onDelete: () -> Unit
) {
    val isBuy = signal.type == SignalType.BUY
    val primaryColor = if (isBuy) BullishGreen else BearishRed
    val badgeBg = if (isBuy) BullishGreenBg else BearishRedBg
    val timeFormat = SimpleDateFormat("hh:mm a, dd MMM yyyy", Locale.getDefault())
    val dateStr = timeFormat.format(Date(signal.timestamp))

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .background(DarkSurface, RoundedCornerShape(10.dp))
            .border(1.dp, DarkBorder, RoundedCornerShape(10.dp))
            .padding(12.dp)
            .testTag("history_item_${signal.id}")
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .background(badgeBg, RoundedCornerShape(4.dp))
                    .padding(horizontal = 8.dp, vertical = 2.dp)
            ) {
                Text(
                    text = signal.type.name,
                    color = primaryColor,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold
                )
            }

            Spacer(modifier = Modifier.width(8.dp))

            Text(
                text = "${signal.pair} • ${signal.timeframe}",
                color = TextPrimary,
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold
            )

            Spacer(modifier = Modifier.weight(1f))

            IconButton(
                onClick = onDelete,
                modifier = Modifier.size(24.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.Delete,
                    contentDescription = "Delete",
                    tint = TextMuted,
                    modifier = Modifier.size(16.dp)
                )
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        // Price targets row
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(DarkSurfaceVariant, RoundedCornerShape(6.dp))
                .padding(8.dp),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column {
                Text("Entry", color = TextMuted, fontSize = 9.sp)
                Text("$${formatNum(signal.entryPrice)}", color = TextPrimary, fontSize = 11.sp, fontWeight = FontWeight.Bold)
            }
            Column {
                Text("Stop Loss", color = TextMuted, fontSize = 9.sp)
                Text("$${formatNum(signal.stopLoss)}", color = BearishRed, fontSize = 11.sp, fontWeight = FontWeight.Bold)
            }
            Column {
                Text("Target 1", color = TextMuted, fontSize = 9.sp)
                Text("$${formatNum(signal.target1)}", color = BullishGreen, fontSize = 11.sp, fontWeight = FontWeight.Bold)
            }
            Column {
                Text("Target 2", color = TextMuted, fontSize = 9.sp)
                Text("$${formatNum(signal.target2)}", color = CyanAccent, fontSize = 11.sp, fontWeight = FontWeight.Bold)
            }
        }

        if (signal.reasons.isNotEmpty()) {
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = "Reason: ${signal.reasons.first()}",
                color = TextSecondary,
                fontSize = 11.sp,
                maxLines = 2
            )
        }

        Spacer(modifier = Modifier.height(4.dp))
        Row(modifier = Modifier.fillMaxWidth()) {
            Text(
                text = "Source: ${if (signal.source == "SCREEN_OCR") "Screen OCR" else "Live Engine"}",
                color = TextMuted,
                fontSize = 10.sp
            )
            Spacer(modifier = Modifier.weight(1f))
            Text(
                text = dateStr,
                color = TextMuted,
                fontSize = 10.sp
            )
        }
    }
}

@Composable
private fun FilterChip(
    label: String,
    isSelected: Boolean,
    onClick: () -> Unit
) {
    Box(
        modifier = Modifier
            .background(
                if (isSelected) CyanAccent else DarkSurfaceVariant,
                RoundedCornerShape(6.dp)
            )
            .clickable(onClick = onClick)
            .padding(horizontal = 8.dp, vertical = 4.dp)
    ) {
        Text(
            text = label,
            color = if (isSelected) DarkSurface else TextSecondary,
            fontSize = 11.sp,
            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
        )
    }
}

private fun formatNum(num: Double): String {
    return if (num >= 100) {
        String.format(Locale.US, "%,.2f", num)
    } else {
        String.format(Locale.US, "%,.4f", num)
    }
}
