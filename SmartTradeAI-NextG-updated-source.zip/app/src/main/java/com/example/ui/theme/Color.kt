package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val DarkBg = Color(0xFF0B0E14)
val DarkSurface = Color(0xFF131A26)
val DarkSurfaceVariant = Color(0xFF1B2436)
val DarkBorder = Color(0xFF28364F)

val CyanAccent = Color(0xFF00E5FF)
val CyanAccentDark = Color(0xFF00B4D8)
val GoldAccent = Color(0xFFFFD600)

val BullishGreen = Color(0xFF00E676)
val BullishGreenBg = Color(0x2200E676)
val BearishRed = Color(0xFFFF3D71)
val BearishRedBg = Color(0x22FF3D71)
val NeutralYellow = Color(0xFFFFC107)
val NeutralYellowBg = Color(0x22FFC107)

val TextPrimary = Color(0xFFF1F5F9)
val TextSecondary = Color(0xFF94A3B8)
val TextMuted = Color(0xFF64748B)

val ChartGridLine = Color(0x1A94A3B8)
val Ema9Color = Color(0xFF00E5FF)
val Ema21Color = Color(0xFFFFAB00)
val VwapColor = Color(0xFFE040FB)
