# SmartTradeAI NextG

Android application project for market monitoring and technical-analysis assistance.

## Current implemented baseline

- Binance Spot public market data for BTC/USDT and ETH/USDT.
- Binance primary API with Binance's public data mirror as a fallback. No other exchange is used as a price fallback, so symbols and prices are not mixed across exchanges.
- Five-second polling refresh while the app process is active. This is periodic polling, not tick-by-tick WebSocket streaming.
- EMA, RSI, MACD, VWAP and ATR calculations and BUY/SELL/HOLD signal heuristics.
- Local signal history, chart OCR and floating assistant components from the supplied project.

## Safety and integration boundaries

- The app is an analysis/monitoring tool. It does not place, edit or cancel orders.
- No withdrawal, transfer, leverage or margin-management functionality is implemented.
- Do not paste exchange API secrets into source code, GitHub, `.env` files committed to the repository, or an APK.
- Authenticated Binance Spot/Futures account balances, open orders, positions, P&L, leverage and liquidation information are **not yet connected**. A secure backend and strictly read-only API-key flow are required before this can be safely enabled. Never grant trading or withdrawal permissions.
- NSE/BSE quotes are **not yet connected**. A permitted market-data provider and its API terms/credentials are required before those prices can be shown. The app must not label delayed data as live.
- The current market-data refresh is polling every five seconds; it is not a WebSocket feed and Android background execution may pause it.

## Build APK

A GitHub Actions workflow is included at `.github/workflows/android-apk.yml`. After pushing to `main`, open the repository's **Actions** tab, select **Android APK Build**, and download the `SmartTradeAI-NextG-debug-apk` artifact after a successful run.

The APK is a debug build for testing. A signed release APK requires a private signing keystore and secrets configured in GitHub Actions; never commit the keystore or passwords.
