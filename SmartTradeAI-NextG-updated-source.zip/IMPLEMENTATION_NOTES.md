# SmartTradeAI NextG — implementation notes

## Applied in this source update
1. Removed the KuCoin ticker fallback. Prices now come only from Binance Spot public endpoints (with Binance's own public mirror as fallback), preventing a different exchange's quote from being presented as Binance.
2. Added a five-second refresh loop while the Android app process is running. This is polling, not a WebSocket stream; Android may pause it in the background.
3. Changed the dashboard badge to identify Binance Spot and the five-second refresh interval.
4. Bumped Android version to 1.1.0 / versionCode 2.
5. Added a GitHub Actions workflow to build and upload a debug APK artifact.

## Not yet implemented — requires additional services/approval
- Binance account linking and private account data (Spot/Futures balances, positions, open orders, P&L, leverage and liquidation price). A secure backend is required to hold a strictly read-only API key. Do not put keys in the app, repository, or APK.
- NSE/BSE live market feed. A licensed/authorized provider and credentials are required. No fabricated or mislabeled prices are shown.
- Binance WebSocket streaming and robust reconnect/background service.
- AI model inference backed by a configured server-side model key. Existing signal generation is local indicator-based analysis, not a guaranteed prediction.
- A signed release APK. The included workflow produces a debug APK only.

## Build
GitHub Actions runs `.github/workflows/android-apk.yml` on pushes to `main`. Download the artifact named `SmartTradeAI-NextG-debug-apk` after a successful run.
