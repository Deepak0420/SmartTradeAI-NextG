plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.smarttradeai.binomo"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.smarttradeai.binomo"
        minSdk = 23
        targetSdk = 35
        versionCode = 1
        versionName = "1.0.0"
    }
}
