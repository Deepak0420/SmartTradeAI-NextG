package com.smarttradeai.binomo

import android.app.Activity
import android.media.projection.MediaProjectionManager
import android.os.Bundle
import android.content.Context
import android.content.Intent
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*

class MainActivity : Activity() {
    private val bg = Color.rgb(8, 13, 24)
    private val panel = Color.rgb(17, 26, 43)
    private val panel2 = Color.rgb(23, 35, 55)
    private val green = Color.rgb(37, 220, 151)
    private val cyan = Color.rgb(65, 190, 255)
    private val muted = Color.rgb(150, 165, 188)
    private lateinit var content: LinearLayout
    private var captureGranted = false
    private val history = mutableListOf<String>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg
        window.navigationBarColor = bg
        showHome()
    }

    private fun base(title: String, subtitle: String): LinearLayout {
        val outer = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(bg)
            setPadding(dp(18), dp(18), dp(18), dp(14))
        }
        val scroll = ScrollView(this)
        content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        scroll.addView(content)
        outer.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        val header = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        header.addView(label("SMARTTRADE AI", 12, cyan, true))
        header.addView(label(title, 27, Color.WHITE, true))
        header.addView(label(subtitle, 13, muted, false))
        content.addView(header)
        content.addView(space(18))
        val nav = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            setPadding(0, dp(8), 0, dp(4))
        }
        listOf("Home", "Live", "Manual", "Tools", "History").forEach { item ->
            val b = TextView(this).apply {
                text = item
                textSize = 11f
                gravity = Gravity.CENTER
                setTextColor(if (item == title) green else muted)
                setPadding(dp(7), dp(9), dp(7), dp(9))
                setOnClickListener {
                    when(item) {
                        "Home" -> showHome()
                        "Live" -> showLive()
                        "Manual" -> showManual()
                        "Tools" -> showTools()
                        "History" -> showHistory()
                    }
                }
            }
            nav.addView(b, LinearLayout.LayoutParams(0, -2, 1f))
        }
        outer.addView(nav)
        return outer
    }

    private fun showHome() {
        val root = base("Home", "BINOMO EDITION  •  AI SIGNAL CENTER")
        content.addView(card {
            addView(label("MARKET ASSISTANT", 12, cyan, true))
            addView(label("Read the chart. Understand the setup.", 21, Color.WHITE, true))
            addView(label("Analysis only — no automatic trades.", 13, muted, false))
        })
        content.addView(space(12))
        content.addView(card {
            addView(label("QUICK START", 12, muted, true))
            addView(actionButton("LIVE CHART ANALYSIS", green) { showLive() })
            addView(space(8))
            addView(actionButton("MANUAL SIGNAL", cyan) { showManual() })
        })
        content.addView(space(12))
        content.addView(card {
            addView(label("ANALYSIS MODES", 12, muted, true))
            addView(label("01  Live screen reading", 16, Color.WHITE, true))
            addView(label("Share Binomo screen only after Android asks permission. Chart reading is a planned module; this starter does not yet extract candles automatically.", 13, muted, false))
            addView(space(10))
            addView(label("02  Manual indicator analysis", 16, Color.WHITE, true))
            addView(label("Enter RSI, EMA and MACD values to get a rule-based UP / DOWN / WAIT result.", 13, muted, false))
        })
        content.addView(space(12))
        content.addView(card {
            addView(label("SUPPORTED SETUP", 12, muted, true))
            addView(label("Timeframes: 1 min • 5 min", 15, Color.WHITE, true))
            addView(label("Indicators: RSI 14, EMA 9/21, MACD, Bollinger Bands, Stochastic, ATR", 13, muted, false))
        })
        setContentView(root)
    }

    private fun showLive() {
        val root = base("Live", "LIVE SCREEN ANALYSIS")
        content.addView(card {
            addView(label("BINOMO SCREEN READER", 12, cyan, true))
            addView(label(if(captureGranted) "Screen permission granted" else "Screen permission not connected", 20, Color.WHITE, true))
            addView(label("Android will show its own screen-sharing permission dialog. This first build only requests permission; candle/OCR recognition is not active yet.", 13, muted, false))
            addView(space(12))
            addView(actionButton("ALLOW SCREEN CAPTURE", green) { requestCapture() })
            addView(space(8))
            addView(label(if(captureGranted) "Permission response received. Recognition engine still needs implementation and validation." else "No screen is captured until you approve the Android dialog.", 12, muted, false))
        })
        content.addView(space(12))
        content.addView(card {
            addView(label("LIVE RESULT", 12, muted, true))
            addView(label("WAIT", 32, cyan, true))
            addView(label("No verified candle data available yet. Do not trade from this placeholder.", 13, muted, false))
        })
        setContentView(root)
    }

    private fun requestCapture() {
        val manager = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        @Suppress("DEPRECATION")
        startActivityForResult(manager.createScreenCaptureIntent(), 401)
    }

    @Deprecated("Activity result callback kept compatible with the starter project")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 401) {
            captureGranted = resultCode == Activity.RESULT_OK && data != null
            showLive()
        }
    }

    private fun showManual() {
        val root = base("Manual", "MANUAL SIGNAL ANALYSIS")
        val rsi = editField("RSI (0–100)", "50")
        val ema9 = editField("EMA 9 value", "101")
        val ema21 = editField("EMA 21 value", "100")
        val macd = editField("MACD histogram (+ / -)", "0.1")
        val tf = Spinner(this).apply {
            adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, listOf("1 minute", "5 minutes"))
        }
        content.addView(card {
            addView(label("ENTER INDICATOR VALUES", 12, cyan, true))
            addView(rsi)
            addView(ema9)
            addView(ema21)
            addView(macd)
            addView(label("TIMEFRAME", 12, muted, true))
            addView(tf, LinearLayout.LayoutParams(-1, dp(48)))
            addView(space(12))
            addView(actionButton("ANALYZE SETUP", green) {
                val result = analyze(rsi.text.toString().toDoubleOrNull(), ema9.text.toString().toDoubleOrNull(),
                    ema21.text.toString().toDoubleOrNull(), macd.text.toString().toDoubleOrNull())
                showResult(result, tf.selectedItem.toString())
            })
        })
        content.addView(space(10))
        content.addView(label("Note: Enter values from the same asset and timeframe. This is a simple educational rule set, not a guaranteed prediction.", 12, muted, false))
        setContentView(root)
    }

    private fun analyze(rsi: Double?, e9: Double?, e21: Double?, macd: Double?): Pair<String, String> {
        if (rsi == null || e9 == null || e21 == null || macd == null || rsi !in 0.0..100.0)
            return "WAIT" to "Please enter valid values. RSI must be between 0 and 100."
        var score = 0
        val reasons = mutableListOf<String>()
        if (e9 > e21) { score++; reasons.add("EMA 9 is above EMA 21") }
        else if (e9 < e21) { score--; reasons.add("EMA 9 is below EMA 21") }
        if (macd > 0) { score++; reasons.add("MACD histogram is positive") }
        else if (macd < 0) { score--; reasons.add("MACD histogram is negative") }
        if (rsi in 52.0..68.0) { score++; reasons.add("RSI supports bullish momentum") }
        else if (rsi in 32.0..48.0) { score--; reasons.add("RSI supports bearish momentum") }
        else if (rsi >= 70 || rsi <= 30) reasons.add("RSI is in an extreme zone; caution")
        val signal = when { score >= 2 -> "UP"; score <= -2 -> "DOWN"; else -> "WAIT" }
        return signal to (if(reasons.isEmpty()) "Signals are mixed or weak." else reasons.joinToString(" • "))
    }

    private fun showResult(result: Pair<String, String>, timeframe: String) {
        history.add(0, "$timeframe  •  ${result.first}  •  ${result.second}")
        val root = base("Manual", "ANALYSIS RESULT")
        content.addView(card {
            addView(label("SUGGESTED DIRECTION", 12, muted, true))
            addView(label(result.first, 38, if(result.first=="UP") green else if(result.first=="DOWN") Color.rgb(255,105,115) else cyan, true))
            addView(label(result.second, 14, Color.WHITE, false))
            addView(space(10))
            addView(label("Strength: ${if(result.first=="WAIT") "Low / unclear" else "Rule match only — not a probability"}", 12, muted, false))
            addView(actionButton("NEW ANALYSIS", cyan) { showManual() })
        })
        setContentView(root)
    }

    private fun showTools() {
        val root = base("Tools", "ADVANCED INDICATORS")
        val items = listOf(
            "RSI 14" to "Momentum and overbought / oversold zones.",
            "EMA 9 / EMA 21" to "Short-term trend direction and crossover.",
            "MACD 12 / 26 / 9" to "Momentum and trend confirmation.",
            "Bollinger Bands 20 / 2" to "Volatility and price range context.",
            "Stochastic 14 / 3 / 3" to "Momentum position; avoid isolated signals.",
            "ATR 14" to "Volatility filter; not a direction predictor."
        )
        items.forEach { (name, desc) -> content.addView(card {
            addView(label(name, 17, Color.WHITE, true))
            addView(label(desc, 13, muted, false))
        }); content.addView(space(8)) }
        setContentView(root)
    }

    private fun showHistory() {
        val root = base("History", "RECENT MANUAL ANALYSES")
        if(history.isEmpty()) content.addView(card { addView(label("No signals saved yet.", 15, muted, false)) })
        history.forEach { entry -> content.addView(card { addView(label(entry, 13, Color.WHITE, false)) }); content.addView(space(8)) }
        content.addView(actionButton("PRACTICE / NEW SIGNAL", green) { showManual() })
        setContentView(root)
    }

    private fun editField(hintText: String, value: String): EditText = EditText(this).apply {
        hint = hintText
        setText(value)
        setTextColor(Color.WHITE)
        setHintTextColor(muted)
        textSize = 15f
        setSingleLine(true)
        inputType = android.text.InputType.TYPE_CLASS_NUMBER or android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL or android.text.InputType.TYPE_NUMBER_FLAG_SIGNED
        setPadding(dp(12), 0, dp(12), 0)
        background = rounded(panel2, 12)
        layoutParams = LinearLayout.LayoutParams(-1, dp(50)).apply { bottomMargin = dp(9) }
    }

    private fun card(block: LinearLayout.() -> Unit): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(15), dp(15), dp(15), dp(15))
        background = rounded(panel, 18)
        block()
    }

    private fun label(textValue: String, size: Int, color: Int, bold: Boolean): TextView = TextView(this).apply {
        text = textValue
        textSize = size.toFloat()
        setTextColor(color)
        if(bold) setTypeface(typeface, Typeface.BOLD)
        setPadding(0, dp(3), 0, dp(5))
    }

    private fun actionButton(textValue: String, color: Int, action: () -> Unit): TextView = TextView(this).apply {
        text = textValue
        gravity = Gravity.CENTER
        textSize = 14f
        setTypeface(typeface, Typeface.BOLD)
        setTextColor(bg)
        setPadding(dp(12), dp(15), dp(12), dp(15))
        background = rounded(color, 14)
        setOnClickListener { action() }
    }

    private fun rounded(color: Int, radius: Int): GradientDrawable =
        GradientDrawable().apply { setColor(color); cornerRadius = dp(radius).toFloat() }

    private fun space(height: Int) = View(this).apply {
        layoutParams = LinearLayout.LayoutParams(1, dp(height))
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
}
