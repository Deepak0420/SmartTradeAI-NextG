# SmartTrade AI — Binomo Edition (Fresh Starter)

A new Android-native starter project for a read-only Binomo chart analysis assistant.

## Current starter features
- New dark dashboard and navigation
- Live screen-capture permission request flow (permission only; no chart OCR/candle extraction yet)
- Manual RSI / EMA 9-21 / MACD rule-based UP / DOWN / WAIT analysis
- Indicator reference page
- In-memory recent analysis history
- 1-minute and 5-minute timeframe selector

## Important limitations
- This is a starter source project, not a finished APK.
- Live screen capture permission does not mean the chart is being read. OCR/candle recognition, validation, and a real signal engine are not implemented yet.
- The manual rule engine is educational and does not calculate a real win probability.
- No auto-trading, no trade-button automation, no guaranteed signals.
- Binomo OTC prices may not match public market feeds.

## Build
Open this folder in Android Studio and build the `app` debug variant, or use a GitHub Actions Android build workflow with JDK 17 and Android SDK 35.
